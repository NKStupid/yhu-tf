# yhu-ansible-playbook

#### Tasks

1. disable firewalld
2. set timezone to Asia/Tokyo
3. disable selinux
4. disable ipv6

5. install az-cli
6. install kubectl
7. install git
8. install jq and yq
9. install jdk

10. install docker
11. create group "infra-user001" with group id 1000
12. create user "infra-user001" with group id 1000 and add to wheel group (then can switch to root)
    add user "infra-user001" to docker group. (then can use docker)

#### 使用的 Azure 资源
- Reource Group Name
    - CSI-Infra-Ansible
- Server Name and Server IP
    - csi-ansible-master(IP: 13.71.159.109)
    - csi-ansible-node1(IP: 52.243.50.120)

#### 软件架构
软件架构说明

 
#### 安装教程

1.  xxxx
2.  xxxx
3.  xxxx

#### 使用说明

1.  xxxx
2.  xxxx
3.  xxxx
